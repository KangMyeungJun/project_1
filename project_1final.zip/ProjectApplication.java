package project_1;

import project_1.View.LoginView;

public class ProjectApplication {
    public static void main(String[] args) {
        new LoginView();
    }
}
